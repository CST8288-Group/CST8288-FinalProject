-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 172.210.82.237    Database: java-final
-- ------------------------------------------------------
-- Server version	5.7.43-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Transaction`
--

DROP TABLE IF EXISTS `Transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `Transaction` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL,
  `quantity` int(11) NOT NULL,
  `lastUpdate` timestamp NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `status` tinyint(4) NOT NULL,
  `datePlaced` timestamp NOT NULL,
  `userId` int(11) NOT NULL,
  `inventoryId` int(11) NOT NULL,
  PRIMARY KEY (`id`,`userId`,`inventoryId`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  KEY `fk_FoodTransfer_User_idx` (`userId`),
  KEY `fk_FoodTransfer_Inventory1_idx` (`inventoryId`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Transaction`
--

LOCK TABLES `Transaction` WRITE;
/*!40000 ALTER TABLE `Transaction` DISABLE KEYS */;
INSERT INTO `Transaction` VALUES (2,2,1,'2024-08-07 03:30:33',0.00,0,'2024-08-07 03:30:33',18,2),(10,2,4,'2024-08-07 05:01:23',1.02,0,'2024-08-07 05:01:23',20,2),(12,3,3,'2024-08-07 05:34:09',9.99,0,'2024-08-07 05:34:09',18,1),(13,2,4,'2024-08-07 05:34:26',NULL,0,'2024-08-07 05:34:26',20,2),(14,3,10,'2024-08-07 15:55:20',9.99,0,'2024-08-07 15:55:20',18,1),(15,2,10,'2024-08-07 15:56:18',NULL,0,'2024-08-07 15:56:18',20,2),(16,2,35,'2024-08-07 15:57:08',NULL,0,'2024-08-07 15:57:08',20,2);
/*!40000 ALTER TABLE `Transaction` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-07 18:45:31
